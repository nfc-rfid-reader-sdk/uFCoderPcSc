DevMsi
======

Custom action DLL for WIX that creates or removes a root-enumerated devnode for a non-Plug-and-Play device


###About

This is a fork from http://www.codeproject.com/Articles/570751/DevMSI-An-Example-Cplusplus-MSI-Wix-Deferred-Custo with improvements and fixes. 

Original code is written by Joe Marley (http://www.codeproject.com/Members/Joe-Marley).


###Keywords
wix, msi, custom action, device node, driver, inf, setup
