var searchData=
[
  ['devmsi_5fapi',['DEVMSI_API',['../devmsi_8h.html#a610c63396ec49d862b0fe5e58bb6f94d',1,'devmsi.h']]]
];
