var searchData=
[
  ['inf2classguid',['Inf2ClassGUID',['../_guid_str_helpers_8cpp.html#a871029ac930bca14ef67f0f561adfd69',1,'Inf2ClassGUID(__inout std::wstring &amp;pathName, __out std::wstring &amp;classStr):&#160;GuidStrHelpers.cpp'],['../_guid_str_helpers_8h.html#a871029ac930bca14ef67f0f561adfd69',1,'Inf2ClassGUID(__inout std::wstring &amp;pathName, __out std::wstring &amp;classStr):&#160;GuidStrHelpers.cpp']]],
  ['isvalid',['IsValid',['../class_auto_close_device_info_list.html#ab3488eb56850c3db517f083e123d8870',1,'AutoCloseDeviceInfoList::IsValid()'],['../class_auto_close_h_key.html#a68be774a57ea2569af35034bb6e53e92',1,'AutoCloseHKey::IsValid()'],['../class_auto_close_service_handle.html#ab0031638501bd8049273de04672cd8ed',1,'AutoCloseServiceHandle::IsValid()']]]
];
