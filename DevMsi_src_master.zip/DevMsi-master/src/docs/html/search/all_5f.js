var searchData=
[
  ['_5fdevmsi_5fexports',['_DEVMSI_EXPORTS',['../stdafx_8h.html#a160d17253947d286539913188c659dbf',1,'stdafx.h']]],
  ['_5fwin32_5fie',['_WIN32_IE',['../targetver_8h.html#ad4562ce705fe4682e63dc8f1ea9dd344',1,'targetver.h']]],
  ['_5fwin32_5fmsi',['_WIN32_MSI',['../targetver_8h.html#ac9d3dbe9617d70c50a0f3e7935dea85f',1,'targetver.h']]],
  ['_5fwin32_5fwinnt',['_WIN32_WINNT',['../targetver_8h.html#ac50762666aa00bd3a4308158510f1748',1,'targetver.h']]]
];
