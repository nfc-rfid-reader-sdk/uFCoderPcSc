var searchData=
[
  ['str2guid',['Str2GUID',['../_guid_str_helpers_8cpp.html#af43068cb2e4ca1a31eec86d4ca1f81b8',1,'Str2GUID(__in const std::wstring &amp;source):&#160;GuidStrHelpers.cpp'],['../_guid_str_helpers_8h.html#af43068cb2e4ca1a31eec86d4ca1f81b8',1,'Str2GUID(__in const std::wstring &amp;source):&#160;GuidStrHelpers.cpp']]]
];
