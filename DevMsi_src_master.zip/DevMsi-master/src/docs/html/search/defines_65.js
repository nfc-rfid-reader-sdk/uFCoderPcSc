var searchData=
[
  ['errmsgbuffersize',['ERRMSGBUFFERSIZE',['../_log_result_8cpp.html#a0faaa65ecedf8da6f046c6a32bff85f4',1,'LogResult.cpp']]]
];
