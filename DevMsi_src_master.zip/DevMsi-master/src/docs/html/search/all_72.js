var searchData=
[
  ['removedevnode',['RemoveDevnode',['../_custom_action_8cpp.html#a82ce00c8fd5133f166ac073b7307331d',1,'CustomAction.cpp']]],
  ['removeservice',['RemoveService',['../_custom_action_8cpp.html#a6992fae81f5d7fa7e6be525d757d63a4',1,'CustomAction.cpp']]]
];
