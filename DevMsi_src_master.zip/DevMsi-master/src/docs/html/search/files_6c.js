var searchData=
[
  ['logresult_2ecpp',['LogResult.cpp',['../_log_result_8cpp.html',1,'']]],
  ['logresult_2eh',['LogResult.h',['../_log_result_8h.html',1,'']]]
];
