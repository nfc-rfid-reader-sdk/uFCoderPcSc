var searchData=
[
  ['autoclose_2eh',['AutoClose.h',['../_auto_close_8h.html',1,'']]]
];
